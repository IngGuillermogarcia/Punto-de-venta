<?php
/*---------- Incluyendo configuraciones ----------*/
require_once "../../config/app.php";
require_once "../../autoload.php";
// Establecer la conexión a la base de datos (ajusta según tus configuraciones)
$host = "Localhost";
$user = "root";
$pass = "";
$db = "ventas";

$conn = new mysqli($host, $user, $pass, $db);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión a la base de datos: " . $conn->connect_error);
}

// Consulta SQL para obtener datos de ventas
$sql = "SELECT * FROM ventas";
$result = $conn->query($sql);

// Configurar FPDF
require('\app\pdf\fpdf.php');
$pdf = new FPDF();
$pdf->AddPage();

// Crear encabezado del informe
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(40, 10, 'Informe de Ventas', 0, 1);

// Crear tabla con datos de ventas
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(20, 10, 'venta_id_detalle', 1);
$pdf->Cell(40, 10, 'venta_detalle_precio_compra', 1);
$pdf->Cell(30, 10, 'Cantidad', 1);
$pdf->Cell(30, 10, 'Precio', 1);
$pdf->Cell(40, 10, 'Fecha', 1);
$pdf->Ln(); // Salto de línea

while ($row = $result->fetch_assoc()) {
    $pdf->Cell(20, 10, $row['id'], 1);
    $pdf->Cell(40, 10, $row['producto'], 1);
    $pdf->Cell(30, 10, $row['cantidad'], 1);
    $pdf->Cell(30, 10, $row['precio'], 1);
    $pdf->Cell(40, 10, $row['fecha'], 1);
    $pdf->Ln(); // Salto de línea
}

// Nombre del archivo PDF
$filename = 'reporte_ventas.pdf';

// Salida del PDF al navegador
$pdf->Output($filename, 'D');
$conn->close();
?>
