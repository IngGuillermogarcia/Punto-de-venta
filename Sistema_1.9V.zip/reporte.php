<?php

require "conexion.php";
require "fpdf.php";

$sql = "SELECT a.venta_id,a.venta_fecha,a.venta_hora,a.venta_total,a.venta_pagado,a.venta_cambio,a.usuario_id,a.cliente_id,a.caja_id,g.venta_detalle_descripcion FROM venta
AS a INNER JOIN venta_detalle AS g ON a.venta_id=g.venta_detalle_id";
$resultado = $mysqli->query($sql);

    $pdf = new FPDF("P", "mm", "letter");
    $pdf->AddPage();
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(200,5,"REPORTE DE VENTAS", 0, 1,"C");

    $pdf->Ln(2);

    $pdf->SetFont("Arial", "B", 9);
    $pdf->Cell(10,5,"ID", 1, 0, "C");
    $pdf->Cell(25,5,"Fecha", 1, 0, "C");
    $pdf->Cell(25,5,"Hora", 1, 0, "C");
    $pdf->Cell(20,5,"Caja", 1, 0, "C");
    $pdf->Cell(40,5,"Descripcion", 1, 0, "C");
    $pdf->Cell(30,5,"Total", 1, 0, "C");
    $pdf->Cell(30,5,"Total pagado", 1, 0, "C");
    $pdf->Cell(30,5,"Cambio", 1, 1, "C");

    $pdf->SetFont("Arial", "", 9);

    while ($fila = $resultado->fetch_assoc()){
        $pdf->Cell(10,5, $fila['venta_id'], 1, 0, "C");
        $pdf->Cell(25,5, $fila['venta_fecha'], 1, 0, "C");
        $pdf->Cell(25,5, $fila['venta_hora'], 1, 0, "C");
        $pdf->Cell(20,5, $fila['caja_id'], 1, 0, "C");
        $pdf->Cell(40,5, $fila['venta_detalle_descripcion'], 1, 0, "C");
        $pdf->Cell(30,5, $fila['venta_total'], 1, 0, "C");
        $pdf->Cell(30,5, $fila['venta_pagado'], 1, 0, "C");
        $pdf->Cell(30,5, $fila['venta_cambio'], 1, 1, "C");

    }


    $pdf->Output();
    