<?php
require('fpdf/fpdf.php');

class pdf extends pdf 
{
function Header()
{
    $this-> SetFont ('Arial','B',16);

    $this-> Cell(60);
    $this-> Cell(70,10,'Reporte de ventas',0,0,'C');

    $this->Ln(20);

    $this->Cell(80,10,'Descripcion',1,0,'c');
    $this->Cell(50,10,'Fecha',1,0,'c');
    $this->Cell(50,10,'Vendedor',1,0,'c');
    $this->Cell(40,10,'No.ticket',1,0,'c');
    $this->Cell(30,10,'Total',1,0,'c');
}

}