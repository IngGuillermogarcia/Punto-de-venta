<?php

/**
 * Conexión a base de datos
 * 
 * Fecha: 17/01/2023
 * Autor: Marco Robles
 * Web:   https://github.com/mroblesdev
 */

$mysqli = new mysqli("localhost", "root", "", "ventas");