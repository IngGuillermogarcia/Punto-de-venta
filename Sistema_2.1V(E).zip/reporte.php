<?php

require "conexion.php";
require "fpdf.php";

$sql = "SELECT e.empresa_direccion,e.empresa_telefono,e.empresa_email,e.empresa_nombre,a.venta_id,a.venta_fecha,a.venta_hora,a.venta_total,a.venta_pagado,a.venta_cambio,a.usuario_id,a.cliente_id,a.caja_id,g.venta_detalle_descripcion,g.venta_detalle_cantidad FROM venta
AS a INNER JOIN venta_detalle AS g INNER JOIN empresa  AS e  ON a.venta_id=g.venta_detalle_id = e.empresa_id";
$resultado = $mysqli->query($sql);
$datos_empresa=$mysqli->query($sql);
$datos_empresa_2=$mysqli->query($sql);
$datos_empresa_3=$mysqli->query($sql);
$datos_empresa_4=$mysqli->query($sql);
    $pdf = new FPDF("P", "mm", "letter");
    $pdf->AddPage();
    
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(190,5,"REPORTE DE VENTAS", 0, 0,"C");
    $pdf->Ln(2);
    
    $pdf->SetFont("Arial", "B", 9);
    $pdf->Cell(350, 5, "Fecha del reporte: " . date("d/m/Y"), 0, 0, "C");
    $pdf->Ln(10);
    $pdf->Image('logo.png' , 175 ,25, 20 , 20,'PNG', 'logo.png');
    $pdf->Ln(6);

    $pdf->SetFont("Arial", "", 10);
        
    while($item = mysqli_fetch_assoc($datos_empresa)){
    $pdf->Cell(50,0,("Nombre de la empresa: ".$item['empresa_nombre']),0,1,'C');
    }
    $pdf->Ln(6);
    while($item_2 = mysqli_fetch_assoc($datos_empresa_2)){
        $pdf->Cell(18,0,("Direccion: ".$item_2['empresa_direccion']),0,1,'C');
        }
    $pdf->Ln(6);
    while($item_3 = mysqli_fetch_assoc($datos_empresa_3)){
        $pdf->Cell(17,0,("Telefono: ".$item_3['empresa_telefono']),0,1,'C');
        }
    $pdf->Ln(6);
    while($item_4 = mysqli_fetch_assoc($datos_empresa_4)){
        $pdf->Cell(13,0,("Email: ".$item_4['empresa_email']),0,1,'C');
        }
            
       
    $pdf->Ln(8);

    $pdf->SetFont("Arial", "B", 9);
    $pdf->Cell(20,5,"Fecha", 1, 0, "C");
    $pdf->Cell(20,5,"Hora", 1, 0, "C");
    $pdf->Cell(10,5,"Caja", 1, 0, "C");
    $pdf->Cell(20,5,"Cantidad", 1, 0, "C");
    $pdf->Cell(55,5,"Articulo", 1, 0, "C");
    $pdf->Cell(20,5,"Total", 1, 0, "C");
    $pdf->Cell(22,5,"Total pagado", 1, 0, "C");
    $pdf->Cell(20,5,"Cambio", 1, 1, "C");

    $pdf->SetFont("Arial", "", 9);

    while ($fila = $resultado->fetch_assoc()){
        $pdf->Cell(20,5, $fila['venta_fecha'], 1, 0, "C");
        $pdf->Cell(20,5, $fila['venta_hora'], 1, 0, "C");
        $pdf->Cell(10,5, $fila['caja_id'], 1, 0, "C");
        $pdf->Cell(20,5, $fila['venta_detalle_cantidad'], 1, 0, "C");
        $pdf->Cell(55,5, $fila['venta_detalle_descripcion'], 1, 0, "C");
        $pdf->Cell(20,5, $fila['venta_total'], 1, 0, "C");
        $pdf->Cell(22,5, $fila['venta_pagado'], 1, 0, "C");
        $pdf->Cell(20,5, $fila['venta_cambio'], 1, 1, "C");

    }


    $pdf->Output();
    