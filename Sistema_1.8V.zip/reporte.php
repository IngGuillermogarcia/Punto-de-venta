<?php

require "conexion.php";
require "fpdf.php";

    $pdf = new FPDF("P", "mm", "letter");
    $pdf->AddPage();
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(150,5,"REPORTE DE VENTAS", 1, 0,"C");
    $pdf->Output();
    